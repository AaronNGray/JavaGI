package cj.util;

public interface Shrinkable extends Modifiable {}
