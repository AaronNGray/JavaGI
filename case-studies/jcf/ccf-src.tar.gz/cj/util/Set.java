package cj.util;

// this is exactly the same as Collection...
public interface Set<E, M> extends Collection<E, M> {

}
