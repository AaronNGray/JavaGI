package cj.util;

public interface Iterator<E, M> {
    public boolean hasNext();
    public E next();

    <M extends Shrinkable>?
    public void remove();
}
