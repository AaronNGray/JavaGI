package cj.util;

public interface ListIterator<E, M> extends Iterator<E, M> {
    <M extends Resizable>?
    public void add(E o);

    <M extends Shrinkable>?
    public void remove();

    <M extends Modifiable>?
    public void set(E o);

    public boolean hasPrevious();
    public int nextIndex();
    public E previous();
    public int previousIndex();    
}

