package cj.util;

// marker interfaces
public interface Modifiable {}
