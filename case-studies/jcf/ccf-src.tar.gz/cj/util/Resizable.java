package cj.util;

public interface Resizable extends Shrinkable {}
