package cj.util;

public interface Collection<E, M> extends cj.lang.Iterable<E, M> {
    <M extends Resizable> ?
    <
    public boolean add(E o);
    public boolean addAll(Collection<? extends E, ?> c);
    >

    <M extends Shrinkable>?
    <
    public void clear();
    public boolean remove(Object o);
    public boolean removeAll(Collection<?, ?> c);
    public boolean retainAll(Collection<?, ?> c);
    >

    public boolean contains(Object o);
    public boolean containsAll(Collection<?, ?> c);
    public boolean equals(Object o);
    public int hashCode();
    public boolean isEmpty();
    public Iterator<E, M> iterator();
    public int size();
    public Object[] toArray();
    public <T> T[] toArray(T[] a);
}
