package cj.lang;

public interface Iterable<E, M> {
    public cj.util.Iterator<E, M> iterator();
}
